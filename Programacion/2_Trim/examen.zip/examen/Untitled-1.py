import sqlite3
help(sqlite3)
