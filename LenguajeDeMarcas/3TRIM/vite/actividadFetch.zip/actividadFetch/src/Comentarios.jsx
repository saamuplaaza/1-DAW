export function Comentario(props){
    <div>
        <h2>{props.nombre}</h2>
        <p>Email: {props.email}</p>
        <p>{props.mensaje}</p>
    </div>
}